'Template done by
' 
'Richard Clark
'Project Hoshimi Lead Manager
'Contact at ori@c2i.fr
' 
Public Interface IActionable
    Sub DoActions()
End Interface
