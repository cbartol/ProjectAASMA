Public Interface IActionable
    Sub DoActions()
End Interface
