The tissue meshes will be cached here by the 3D engine to reduce loading
times. You can safely delete all files in here.